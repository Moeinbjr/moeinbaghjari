<?php
session_start();

// --- بخش امنیتی: جلوگیری از اسپم و درگیر شدن رم ---
$limit_requests = 5; // حداکثر ۵ درخواست
$time_window = 60;   // در هر ۱ دقیقه
$user_ip = $_SERVER['REMOTE_ADDR'];
$current_time = time();

if (!isset($_SESSION['last_requests'])) {
    $_SESSION['last_requests'] = [];
}

// پاک کردن درخواست‌های قدیمی
$_SESSION['last_requests'] = array_filter($_SESSION['last_requests'], function($timestamp) use ($current_time, $time_window) {
    return ($current_time - $timestamp) < $time_window;
});

// چک کردن محدودیت
if (count($_SESSION['last_requests']) >= $limit_requests) {
    http_response_code(429);
    die("تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً ۱ دقیقه صبر کنید.");
}

// اضافه کردن درخواست فعلی به لیست
$_SESSION['last_requests'][] = $current_time;
// --- پایان بخش امنیتی ---


// ۱. تنظیمات ربات تلگرام
$telegram_token = "8533526157:AAEsWZsqcFNKShnS_xyiYu2Fr8dceh_fZ2Y"; 
$chat_id = "7802079043";

$data = $_POST;
$date = date("Y/m/d | H:i");

function clean($input) {
    if (is_array($input)) {
        return implode(', ', array_map('clean', $input));
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

$content = "";
$file = "";
$notif_message = "";

if (isset($data['تلفن']) && isset($data['نوع_سایت'])) {
    // فرم ثبت سفارش
    $file = 'moein_baghjari_2108_sabt_sefaresh.html';
    $phone = clean($data['تلفن']);
    $telegram = clean($data['آیدی_تلگرام']);
    $site_type = clean($data['نوع_سایت']);
    $budget = clean($data['بودجه']);
    $amenities = isset($data['امکانات']) ? clean($data['امکانات']) : 'انتخاب نشده';
    $desc = nl2br(clean($data['توضیحات']));

    $content = '
    <div style="direction:rtl; font-family:tahoma; border:2px solid #4f46e5; margin:15px; padding:20px; border-radius:20px; background:#f0f4ff;">
        <h3 style="color:#4f46e5; margin-top:0;">🚀 سفارش جدید پروژه</h3>
        <p><b>📱 شماره تماس:</b> '.$phone.'</p>
        <p><b>🆔 تلگرام:</b> '.$telegram.'</p>
        <p><b>🌐 نوع سایت:</b> '.$site_type.'</p>
        <p><b>💰 بودجه:</b> '.$budget.'</p>
        <p><b>🛠 امکانات:</b> '.$amenities.'</p>
        <div style="background:#fff; padding:10px; border:1px dashed #ccc; border-radius:10px;">
            <b>📝 توضیحات:</b><br>'.$desc.'
        </div>
        <hr style="opacity:0.2;">
        <small style="color:#666;">ثبت شده در: '.$date.'</small>
    </div>' . PHP_EOL;
    
    $notif_message = "🔔 معین جان! یک سفارش جدید (".$site_type.") ثبت شد.";

} elseif (isset($data['پیام'])) {
    // فرم تماس با ما
    $file = 'moein_baghjari_2108_form_tamas.html';
    $name = clean($data['نام']);
    $phone = clean($data['شماره_تماس']);
    $msg = nl2br(clean($data['پیام']));

    $content = '
    <div style="direction:rtl; font-family:tahoma; border:2px solid #ec4899; margin:15px; padding:20px; border-radius:20px; background:#fff0f6;">
        <h3 style="color:#ec4899; margin-top:0;">📩 پیام تماس جدید</h3>
        <p><b>👤 نام فرستنده:</b> '.$name.'</p>
        <p><b>📱 شماره تماس:</b> '.$phone.'</p>
        <div style="background:#fff; padding:10px; border:1px dashed #ccc; border-radius:10px;">
            <b>💬 متن پیام:</b><br>'.$msg.'
        </div>
        <hr style="opacity:0.2;">
        <small style="color:#666;">ارسال شده در: '.$date.'</small>
    </div>' . PHP_EOL;
    
    $notif_message = "📩 معین جان! یک پیام تماس جدید از طرف (".$name.") داری.";
}

if ($file != "" && $content != "") {
    file_put_contents($file, $content, FILE_APPEND);
    $proxy_url = "https://api.telegram-proxy.org/bot$telegram_token/sendMessage?chat_id=$chat_id&text=" . urlencode($notif_message);
    $ctx = stream_context_create(['http' => ['timeout' => 5]]);
    @file_get_contents($proxy_url, false, $ctx);
    echo "Success";
}
?>
